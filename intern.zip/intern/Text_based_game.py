import random

def number_guessing_game():
    # Set the range for the random number
    lower_limit = 1
    upper_limit = 100

    # Set the maximum number of attempts
    max_attempts = 10
    attempts = 0

    # Generate a random number for the player to guess
    secret_number = random.randint(lower_limit, upper_limit)

    print("Welcome to the Number Guessing Game!")
    print(f"I'm thinking of a number between {lower_limit} and {upper_limit}.")

    while attempts < max_attempts:
        # Get the player's guess
        guess = int(input("Your guess: "))

        # Increment the number of attempts
        attempts += 1

        # Check if the guess is correct
        if guess == secret_number:
            print(f"Congratulations! You guessed the number {secret_number} in {attempts} attempts.")
            break
        elif guess < secret_number:
            print("Too low. Try again.")
        else:
            print("Too high. Try again.")

    # If the player couldn't guess the number in the allowed attempts
    if attempts == max_attempts:
        print(f"Sorry, you've run out of attempts. The correct number was {secret_number}.")

# Run the game
number_guessing_game()
