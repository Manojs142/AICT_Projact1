import requests
from bs4 import BeautifulSoup
import csv

def scrape_weather_data(url):
    # Send a GET request to the website
    response = requests.get(url)

    if response.status_code == 200:
        # Parse the HTML content of the page
        soup = BeautifulSoup(response.text, 'html.parser')

        # Extract relevant information (replace with actual HTML elements)
        temperature = soup.find('span', {'class': 'temperature'}).text
        humidity = soup.find('span', {'class': 'humidity'}).text

        return temperature, humidity
    else:
        print(f"Failed to retrieve the page. Status code: {response.status_code}")
        return None, None

def save_to_csv(data, filename='weather_data.csv'):
    headers = ['Temperature', 'Humidity']

    with open(filename, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(headers)
        writer.writerow(data)

if __name__ == "__main__":
    # Replace this URL with the actual URL of the website you want to scrape
    website_url = 'https://example.com/weather'
    
    # Scrape data from the website
    temperature, humidity = scrape_weather_data(website_url)

    if temperature is not None and humidity is not None:
        # Save the scraped data to a CSV file
        data_to_save = [temperature, humidity]
        save_to_csv(data_to_save)
        print("Data scraped and saved successfully.")
    else:
        print("Failed to scrape data.")
